package de.thm.swtp.gateway

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.autoconfigure.security.oauth2.client.OAuth2ClientProperties
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.security.config.web.server.ServerHttpSecurity
import org.springframework.security.web.server.SecurityWebFilterChain
import org.springframework.security.web.server.authentication.logout.RedirectServerLogoutSuccessHandler
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.server.ServerWebExchange
import org.springframework.web.util.UriComponentsBuilder
import java.net.URI

@SpringBootApplication
class GatewayApplication

@Configuration
class SecurityConfig {

    @Bean
    fun securityWebFilterChain(serverHttpSecurity: ServerHttpSecurity): SecurityWebFilterChain {
        serverHttpSecurity
                .authorizeExchange {
                    it
                            .pathMatchers("/signout").permitAll()
                            .pathMatchers("/favicon.ico", "/*.js", "/*.css").permitAll()
                            .anyExchange().authenticated()
                }
                .oauth2Login()
                .and()
                .logout {
                    it.logoutSuccessHandler(logoutSuccessHandler())
                }
                .csrf().disable()

        return serverHttpSecurity.build()
    }

    private fun logoutSuccessHandler(): RedirectServerLogoutSuccessHandler {
        val handler = RedirectServerLogoutSuccessHandler()
        handler.setLogoutSuccessUrl(URI.create("/signout"))
        return handler
    }
}

@Controller
class LogoutController(
        private val oAuth2ClientProperties: OAuth2ClientProperties
) {

    @GetMapping(path = ["signout"])
    fun logout(serverWebExchange: ServerWebExchange): ResponseEntity<Void> {
        val issuerUri = oAuth2ClientProperties.provider["swtp"]?.issuerUri
                ?: return ResponseEntity
                        .status(HttpStatus.FOUND)
                        .location(URI.create("/"))
                        .build()

        val redirectUri = UriComponentsBuilder
                .fromUri(serverWebExchange.request.uri)
                .replacePath("")
                .build()

        return ResponseEntity
                .status(HttpStatus.FOUND)
                .location(
                        UriComponentsBuilder.fromHttpUrl(issuerUri)
                                .path("/protocol/openid-connect/logout")
                                .queryParam("redirect_uri", redirectUri)
                                .build()
                                .toUri()
                )
                .build()
    }

}

fun main(args: Array<String>) {
    runApplication<GatewayApplication>(*args)
}