package de.thm.swtp.gateway

import org.springframework.cloud.gateway.filter.GatewayFilter
import org.springframework.cloud.security.oauth2.gateway.TokenRelayGatewayFilterFactory
import org.springframework.http.HttpHeaders
import org.springframework.http.server.reactive.ServerHttpRequest
import org.springframework.security.core.Authentication
import org.springframework.security.oauth2.client.OAuth2AuthorizeRequest
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient
import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientManager
import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientProviderBuilder
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository
import org.springframework.security.oauth2.client.web.DefaultReactiveOAuth2AuthorizedClientManager
import org.springframework.security.oauth2.client.web.server.ServerOAuth2AuthorizedClientRepository
import org.springframework.security.oauth2.core.OAuth2AccessToken
import org.springframework.stereotype.Component
import org.springframework.web.server.ServerWebExchange
import reactor.core.publisher.Mono
import java.security.Principal
import java.time.Duration

/**
 * Custom TokenRelayGatewayFilter with token refresh.
 * To be removed when Spring issue {@see https://github.com/spring-cloud/spring-cloud-security/issues/175} is closed.
 */
@Component
class TokenRelayWithTokenRefreshGatewayFilterFactory(
        authorizedClientRepository: ServerOAuth2AuthorizedClientRepository,
        clientRegistrationRepository: ReactiveClientRegistrationRepository
) : TokenRelayGatewayFilterFactory(authorizedClientRepository) {

    private val authorizedClientManager: ReactiveOAuth2AuthorizedClientManager

    private val accessTokenExpiresSkew = Duration.ofSeconds(3)

    init {
        this.authorizedClientManager = createDefaultAuthorizedClientManager(clientRegistrationRepository, authorizedClientRepository)
    }

    override fun apply(): GatewayFilter {
        return apply(null)
    }

    override fun apply(config: Any?): GatewayFilter {
        return GatewayFilter { exchange, chain ->
            exchange
                    .getPrincipal<Principal>()
                    .filter { it is OAuth2AuthenticationToken }
                    .cast(OAuth2AuthenticationToken::class.java)
                    .flatMap { authorizeClient(it) }
                    .map { it?.accessToken }
                    .filter { it != null }
                    .map { withBearerAuth(exchange, it!!) }
                    .defaultIfEmpty(exchange)
                    .flatMap { chain.filter(exchange) }
        }
    }

    private fun createDefaultAuthorizedClientManager(
            clientRegistrationRepository: ReactiveClientRegistrationRepository,
            authorizedClientRepository: ServerOAuth2AuthorizedClientRepository): ReactiveOAuth2AuthorizedClientManager {
        val authorizedClientProvider = ReactiveOAuth2AuthorizedClientProviderBuilder.builder()
                .authorizationCode()
                .refreshToken { configurer: ReactiveOAuth2AuthorizedClientProviderBuilder.RefreshTokenGrantBuilder -> configurer.clockSkew(accessTokenExpiresSkew) }
                .clientCredentials { configurer: ReactiveOAuth2AuthorizedClientProviderBuilder.ClientCredentialsGrantBuilder -> configurer.clockSkew(accessTokenExpiresSkew) }
                .password { configurer: ReactiveOAuth2AuthorizedClientProviderBuilder.PasswordGrantBuilder -> configurer.clockSkew(accessTokenExpiresSkew) }
                .build()
        val authorizedClientManager = DefaultReactiveOAuth2AuthorizedClientManager(
                clientRegistrationRepository,
                authorizedClientRepository
        )
        authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider)
        return authorizedClientManager
    }

    private fun withBearerAuth(exchange: ServerWebExchange, accessToken: OAuth2AccessToken): ServerWebExchange {
        return exchange
                .mutate()
                .request { r: ServerHttpRequest.Builder -> r.headers { headers: HttpHeaders -> headers.setBearerAuth(accessToken.tokenValue) } }
                .build()
    }

    private fun authorizeClient(oAuth2AuthenticationToken: OAuth2AuthenticationToken): Mono<OAuth2AuthorizedClient?>? {
        val clientRegistrationId = oAuth2AuthenticationToken.authorizedClientRegistrationId
        return Mono.defer { authorizedClientManager.authorize(createOAuth2AuthorizeRequest(clientRegistrationId, oAuth2AuthenticationToken)) }
    }

    private fun createOAuth2AuthorizeRequest(clientRegistrationId: String, principal: Authentication): OAuth2AuthorizeRequest? {
        return OAuth2AuthorizeRequest.withClientRegistrationId(clientRegistrationId).principal(principal).build()
    }

}